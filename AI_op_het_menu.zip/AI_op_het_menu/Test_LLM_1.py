from openai import OpenAI

client = OpenAI(api_key="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")

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "Leg in het kort uit wat een API is."}
    ],
)

print(response.choices[0].message.content)