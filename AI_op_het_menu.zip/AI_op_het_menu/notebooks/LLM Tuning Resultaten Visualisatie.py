# Databricks notebook source
# DBTITLE 1,Introductie
# MAGIC %md
# MAGIC ## LLM Hypertuning Resultaten – Parallel Coordinates Plot
# MAGIC
# MAGIC Dit notebook leest de tuning-resultaten uit `llm_tuning_results.csv` en visualiseert alle trials als een **parallel coordinates plot**. Elke lijn is één trial; de kleur geeft de `objective_value` weer (blauw = hoog / goed, rood = laag).

# COMMAND ----------

# DBTITLE 1,Laad data en maak parallel coordinates plot
import pandas as pd
import plotly.graph_objects as go

# ── Data laden ────────────────────────────────────────────
CSV_PATH = "/Workspace/Users/rgoedings@hanos.nl/AI_op_het_menu/llm_tuning_results.csv"
df = pd.read_csv(CSV_PATH)

print(f"{len(df)} trials geladen.")
df.head()

# COMMAND ----------

# DBTITLE 1,Parallel Coordinates Plot
import plotly.graph_objects as go

# ── Kolommen voor de assen ────────────────────────────────
# Volgorde: objective eerst, dan hyperparameters, dan metrics
axes = [
    "objective_value",
    "trial_id",
    "temperature",
    "top_p",
    "max_tokens",
    "plausibility",
    "strategic_value",
    "coherence",
    "consistency",
    "diversity",
    "latency",
    "cost",
]

# Alleen kolommen gebruiken die in de CSV staan
axes = [c for c in axes if c in df.columns]

# ── Dimensies bouwen ─────────────────────────────────────
dimensions = []
for col in axes:
    dimensions.append(
        dict(
            label=col,
            values=df[col],
            range=[df[col].min(), df[col].max()],
        )
    )

# ── Plot ─────────────────────────────────────────────────
fig = go.Figure(
    data=go.Parcoords(
        line=dict(
            color=df["objective_value"],
            colorscale=[
                [0.0, "rgb(220, 50, 50)"],   # laag = rood
                [0.5, "rgb(200, 160, 200)"],  # midden = licht
                [1.0, "rgb(50, 50, 220)"],    # hoog = blauw
            ],
            showscale=True,
            cmin=df["objective_value"].min(),
            cmax=df["objective_value"].max(),
            colorbar=dict(title="Objective"),
        ),
        dimensions=dimensions,
    )
)

fig.update_layout(
    title="LLM Hypertuning – Parallel Coordinates",
    font=dict(size=12),
    width=1400,
    height=600,
    margin=dict(l=80, r=80, t=60, b=40),
)

displayHTML(fig.to_html())