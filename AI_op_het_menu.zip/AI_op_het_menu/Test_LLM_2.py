"""
LLM experiment runner with:
- Multiple identical runs
- Stability metric S via mean pairwise cosine similarity
- Optional retrieval metrics: CGR, hallucination rate, context precision
- Writes results per run + summary to:
  /Workspace/Users/rgoedings@hanos.nl/Test_LLM_3/results/
"""

from openai import OpenAI
import time
import itertools
import math
import json
import os
from typing import Optional, List

# =============================
# CONFIG
# =============================

API_KEY = "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"  # <-- VERVANG DIT
RESULTS_BASE_PATH = "/Workspace/Users/rgoedings@hanos.nl/Test_LLM_3/results"

client = OpenAI(api_key=API_KEY)


# =============================
# COSINE SIMILARITY
# =============================

def cosine_similarity(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def mean_pairwise_cosine(embeddings: List[List[float]]) -> float:
    R = len(embeddings)
    if R < 2:
        return 1.0
    sims = []
    for i, j in itertools.combinations(range(R), 2):
        sims.append(cosine_similarity(embeddings[i], embeddings[j]))
    return sum(sims) / len(sims)


# =============================
# LLM CALLS
# =============================

def generate_answer(model: str, question: str, context: Optional[str] = None) -> str:
    messages = []

    if context:
        messages.append({
            "role": "system",
            "content": "Gebruik uitsluitend de gegeven context. Verzinnen is niet toegestaan."
        })
        messages.append({
            "role": "user",
            "content": f"CONTEXT:\n{context}\n\nVRAAG:\n{question}"
        })
    else:
        messages.append({
            "role": "user",
            "content": question
        })

    resp = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0.7
    )

    return resp.choices[0].message.content


def embed_texts(texts: List[str], model: str = "text-embedding-3-small") -> List[List[float]]:
    resp = client.embeddings.create(model=model, input=texts)
    return [item.embedding for item in resp.data]


# =============================
# RETRIEVAL METRICS (OPTIONEEL)
# =============================

def extract_claims(answer: str, judge_model: str = "gpt-4o-mini") -> List[str]:
    prompt = f"""
Extraheer feitelijke claims uit het antwoord.
Geef JSON terug als:
{{"claims": ["claim1", "claim2"]}}

ANTWOORD:
{answer}
"""
    resp = client.chat.completions.create(
        model=judge_model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )

    try:
        data = json.loads(resp.choices[0].message.content)
        return data.get("claims", [])
    except:
        return []


def claim_supported_by_context(claim: str, context: str, judge_model="gpt-4o-mini") -> int:
    prompt = f"""
Wordt de CLAIM ondersteund door de CONTEXT?
Antwoord met JSON: {{"supported": 0 of 1}}

CONTEXT:
{context}

CLAIM:
{claim}
"""
    resp = client.chat.completions.create(
        model=judge_model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )

    try:
        data = json.loads(resp.choices[0].message.content)
        return int(data.get("supported", 0))
    except:
        return 0


def context_precision(top_k_fragments: List[str], answer: str, k: int) -> float:
    if not top_k_fragments or k == 0:
        return 0.0

    relevant = 0
    for frag in top_k_fragments[:k]:
        prompt = f"""
Is dit fragment relevant voor het antwoord?
Antwoord met JSON: {{"relevant": 0 of 1}}

FRAGMENT:
{frag}

ANTWOORD:
{answer}
"""
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )

        try:
            data = json.loads(resp.choices[0].message.content)
            relevant += int(data.get("relevant", 0))
        except:
            pass

    return relevant / k


# =============================
# MAIN EVALUATION FUNCTION
# =============================

def evaluate_architecture(
    model: str,
    question: str,
    runs: int,
    experiment_name: str,
    retrieval_context_per_run: Optional[List[str]] = None,
    top_k_fragments_per_run: Optional[List[List[str]]] = None,
    k: int = 5,
    w1: float = 0.25,
    w2: float = 0.25,
    w3: float = 0.25,
    w4: float = 0.25
):

    experiment_path = os.path.join(
        RESULTS_BASE_PATH,
        f"experiment_{experiment_name}"
    )
    os.makedirs(experiment_path, exist_ok=True)

    answers = []
    latencies = []
    per_run_cgr = []
    per_run_cp = []

    # -------------------------
    # Runs uitvoeren
    # -------------------------
    for r in range(runs):

        context = retrieval_context_per_run[r] if retrieval_context_per_run else None

        start = time.time()
        answer = generate_answer(model, question, context)
        latency = time.time() - start

        answers.append(answer)
        latencies.append(latency)

        run_data = {
            "run": r + 1,
            "answer": answer,
            "latency_seconds": latency
        }

        # Retrieval metrics
        if retrieval_context_per_run:
            claims = extract_claims(answer)

            if len(claims) == 0:
                cgr = 1.0
            else:
                supports = [
                    claim_supported_by_context(c, retrieval_context_per_run[r])
                    for c in claims
                ]
                cgr = sum(supports) / len(supports)

            cp = context_precision(
                top_k_fragments_per_run[r] if top_k_fragments_per_run else [],
                answer,
                k
            )

            run_data["CGR"] = cgr
            run_data["hallucination_rate"] = 1 - cgr
            run_data["context_precision"] = cp

            per_run_cgr.append(cgr)
            per_run_cp.append(cp)

        # Opslaan per run
        with open(os.path.join(experiment_path, f"run_{r+1}.json"), "w", encoding="utf-8") as f:
            json.dump(run_data, f, indent=2, ensure_ascii=False)

    # -------------------------
    # Stabiliteit berekenen
    # -------------------------
    embeddings = embed_texts(answers)
    stability = mean_pairwise_cosine(embeddings)

    avg_latency = sum(latencies) / len(latencies)

    avg_cgr = sum(per_run_cgr) / len(per_run_cgr) if per_run_cgr else None
    avg_cp = sum(per_run_cp) / len(per_run_cp) if per_run_cp else None
    avg_h = 1 - avg_cgr if avg_cgr is not None else None

    total_score = None
    if avg_cgr is not None:
        total_score = (
            w1 * stability +
            w2 * avg_cgr +
            w3 * (1 - avg_h) +
            w4 * avg_cp
        )

    summary = {
        "stability_S": stability,
        "avg_latency": avg_latency,
        "avg_CGR": avg_cgr,
        "avg_hallucination_rate": avg_h,
        "avg_context_precision": avg_cp,
        "total_score": total_score
    }

    with open(os.path.join(experiment_path, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    return summary


# =============================
# VOORBEELD
# =============================

if __name__ == "__main__":

    result = evaluate_architecture(
        model="gpt-4o-mini",
        question="Leg in het kort uit wat een API is.",
        runs=5,
        experiment_name="baseline_test"
    )

    print(json.dumps(result, indent=2, ensure_ascii=False))