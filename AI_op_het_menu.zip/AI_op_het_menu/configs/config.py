"""
Project-wide configuration.

Tip:
- Zet je API key liever in een env var (OPENAI_API_KEY).
- Voor nu ondersteunen we ook een hardcoded key in deze config.
"""

from __future__ import annotations
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class OpenAIConfig:
    api_key: str
    base_url: str | None = None  # optioneel (bv. Azure / proxy)
    timeout_seconds: int = 60

def load_openai_config() -> OpenAIConfig:
    # 1) env var (aanrader)
    api_key = os.getenv("OPENAI_API_KEY")

    # 2) fallback: hardcoded (alleen voor snelle tests)
    if not api_key:
        api_key = "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"

    base_url = os.getenv("OPENAI_BASE_URL") or None
    timeout = int(os.getenv("OPENAI_TIMEOUT_SECONDS", "60"))
    return OpenAIConfig(api_key=api_key, base_url=base_url, timeout_seconds=timeout)
